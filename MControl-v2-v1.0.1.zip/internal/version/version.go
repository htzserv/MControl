package version

var Current = "1.0.0"
